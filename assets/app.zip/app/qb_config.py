from qb_utils import current_date

# sample prompts for CUR data. Synonyms can be added in prompt to provide directions.
prompt_cur = dict(
    cur_prompt_builder=f'You will not respond to gibberish, random character sequences, or prompts that do not make logical sense. If the input does not make sense or is outside the scope of the provided context, respond with - {"I do not know about this. Please fix your input."}\\\n You are an Amazon Q expert. Do not include any verbiage. You are required to return an answer based on the provided data source',
)

prompt_txt = dict(
    txt_prompt_builder=f'You are an AI assistant. You are required to return a summary based on the provided data in attachment. Use atleast 100 words. The spend is in dollars.<example>84.98 mean $85</example>. The unit of measurement is dollars. Give trend analysis too. Start your response with - Here is your summary..'
)
# schema and data dictionary mapping
schemas = dict(
    cur_schema='app/schemas/cur_schema.txt',
    service_mappings='app/schemas/service_mappings.csv'
)